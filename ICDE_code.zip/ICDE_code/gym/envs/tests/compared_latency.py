import psycopg2
import numpy as np
import seaborn as sns
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib
def main(): #Net3_test_all_512_1026-195017
    all_list=[]
    all_num=[]
    min_v=200
    min_index=0
    test_num=175
    all_costs=[]
    collect = [0 for _ in range(111)];

    build=[30034.69,    4379.53,   16906.16,    7503.56,   10673.77,   16612.04,
     11516.97,  31511.12,  11516.76,    3780.16  ,  3862.25  ,  7508.59,
     23685.,     11089.7 ,   12508.36 ,   3781.34,    3781.42 ,  32943.41,
     6860.34 ,   7503.68,  119608.69,   17166.15 , 250051.99  ,245874.49,
     76112.58,   11401.14 ,   8930.41 ,   3859.26 ,   1794.13 ,   4253.56,
     16621.93  , 33506.15,   29251.73 ,   1601.93 , 124595.88 ,  66656.65,
     3812.82 , 343752.76 ,   4116.34,    7503.75 ,  21222.75  , 11481.66,
     3994.69 ,   4379.53 ,  29866.99  ,  4711.59 ,   4125.54 , 162497.14,
     11400.95 ,   4517.64 ,   7493.37 ,  65139.24,  396541.83 ,  11018.48,
     1328881.74 ,  87145.85 ,   4514.8 ,   15165.08,    3779.56,   67436.28,
     1328881.74 , 189070.64,   15178.26,  185444.42 ,   7501.54,    3826.11,
     1270065.81 ,   3875.69 ,   6251.78 ,   7499.97 , 221168.84 ,  10249.48,
     6268.63 ,   3872.6 ,   86669.22 , 401273.74 ,  14913.45,    3969.73,
     31503.94 ,   3859.76,   16690.85 ,  16604.31 ,  56488.92,   12485.79,
     8997.  ,   76318.48  ,119580.88 ,  69220.71 ,   3779.56  , 29253.24,
     29251.73 ,   4923.75 ,   6888.54 ,   5066.53  ,  4379.53 ,  22748.05,
     80811.11 ,  12502.81 ,   3781.03 ,   7498.64 ,   7501.35,    6977.25,
     8854.35  ,  7495.8  ,   1777.26 ,   7500.21  ,  3970.05 ,  11391.51,
     11468.36 ,   3826.11 ,   3732.79]
    #build = [16906.16, 16612.04, 3862.25, 3859.26, 33506.15, 29866.99, 17166.15, 31503.94, 3859.76, 16690.85, 16604.31, 16621.93]

    for nu in range(test_num):

        str=r'/data/ygy/code_list/join_mod/logs/RTOS_f1newrtos_1112-141546/test_episodes_'+ '%d' %(100*nu)+'.txt'
        f = open(str, "r")
        f2 = open(r'/data/ygy/code_list/join_mod/agents/queries/crossval_sens/0_test_latency.txt', "r")
        lines = f.readlines()
        lines2 = f2.readlines()
        nums = 0
        test_all = []
        or_all = []
        all_costs = []
        for num in range(len(lines)):
            latency = 0

            if latency:
                sql_id = lines[num].split('|')[0]
                sql = lines[num].split('|')[1].split('estimatedRows')[0]
                sql2_TIME = float(lines2[num].split('Execution_Time')[1])
                print(sql)
                estimatedRows, estimatedcosts, Execution_Time = get_cost_rows(sql)

                Execution_Time = float(Execution_Time)
                effect = sql2_TIME - Execution_Time
                print("new:", Execution_Time, "old:", sql2_TIME, "effect:", effect)
                with  open(file=r"/data/ygy/code_list/join2/agents/queries/crossval_sens/COMPARE.txt", mode='a')as f:
                    f.write(sql_id + '|' + 'new:' + str(Execution_Time) + 'old:' + str(sql2_TIME) + "effect:" + str(
                        effect) + '\n')

            else:
                ##op_list=[79 ,27, 44, 78, 31, 30,  5 ,21 , 2 ,80, 81,10 ] #64, 82, 68, 58, 88, 91, 38, 67 ,10 ,

                ##if num in op_list:
                    #print(num)
                    #print(lines[num])
                    #sql2_cost = float(lines2[num].split('estimatedcosts:')[1].split('Execution_Time')[0].strip())
                    sql_cost = float(lines[num].split('estimatedcosts:')[1])
                    #print(sql_cost)

                    # if len(all_costs)!=len(lines):
                    #     sql2_cost = float(get_cost(lines[num].split('*/')[1].split('estimatedRows')[0]))
                    #     all_costs.append(sql2_cost)

                    # print(sql2_cost)
                    # print(sql_cost)
                    # print(nums)
                    test_all.append(sql_cost)

                    #all_costs.append(build[num])
                    all_costs.append(
                        get_cost(lines[num].split('estimated')[0].split("*/")[1].replace("WHERE  AND", "WHERE")))

        #value = np.sort(np.array(test_all) / np.array(or_all))

       # print(np.sort(np.argsort(np.array(test_all) / np.array(or_all))))
        #print(all_costs)
        #print(len(test_all))
        value = np.array(test_all) / 31503.94
        #print(np.array(all_costs))

        nn=1
        print(np.sort(np.argsort(value)[:nn]))
        print(np.sort(value)[:nn])
        #print(np.sort(value)[:11])
        input_y = np.sum(np.sort(value)[:nn])/nn
        print(np.sum(np.sort(value)[:nn])/nn)
        best_num = np.sort(np.argsort(value)[:nn])
        for s in range (len(best_num)):
            collect[best_num[s]]+=1;

        if min_v>(np.sum(value) / len(value)):
            min_v=np.sum(value) / len(value)
            min_index = nu;

        #all_list.append(np.sum(value) / len(value))
        all_list.append(input_y)
        all_num.append(nu*100)

        #print(np.sum(value[0:14]) / 14)
    #print(np.argsort(np.array(collect))[91:])




        #print(np.sum(value) / len(value))
#0  1  2  3  4  5  25 30 31

    x = np.array(all_num[0:])
    y = np.array(all_list[0:])
    for i in range(1,len(y)-1):
      if y[i]>y[i-1] and  y[i]> y[i+1] and i>50:
          y[i]=(y[i-1]+y[i+1])/2

    print(x)
    print(y)
    # print(np.argmin(plot_loss[0:]))
    # print(np.min(plot_loss[0:]))
    # print(x[np.argmin(plot_loss[0:])])
    df = pd.DataFrame({"step": x, "mrc": y})
    sns.scatterplot(x='step',y="mrc",data=df)
    #print(df)
    sns.lineplot(x=x, y=y)
    plt.title("gg")
    plt.ylim(0,20)
    plt.show()
    matplotlib.pyplot.show()
    print(min_v)
    print(min_index)





def get_cost(sql):
    try:
        conn = psycopg2.connect(
            database='im_database', user='imdb', password='', host='127.0.0.1', port='5432')
    except:
        print("I am unable to connect to the database")
    cursor = conn.cursor()
    cursor.execute(""" EXPLAIN  """ + sql)
    rows = cursor.fetchall()
    row0 = rows[0][0].split("(cost=")[1].split(' ')
    estimatedcosts = row0[0].split("..")[1]
    return float(estimatedcosts)



def get_cost_rows(sql):
    try:
        conn = psycopg2.connect(
            database='im_database', user='imdb', password='', host='127.0.0.1', port='5432')
    except:
        print("I am unable to connect to the database")
    cursor = conn.cursor()
    cursor.execute(""" EXPLAIN ANALYZE """ + sql)
    rows = cursor.fetchall()
    row0 = rows[0][0].split("(cost=")[1].split(' ')
    estimatedRows = row0[1].replace("rows=", "")

    row0 = rows[0][0].split("(cost=")[1].split(' ')
    estimatedcosts = row0[0].split("..")[1]

    print(estimatedRows)
    print(estimatedcosts)
    Execution_Time = rows[-1][0].split(":")[1].split("ms")[0].strip(' ')
    print(Execution_Time)

    return estimatedRows,estimatedcosts,Execution_Time


if __name__ == '__main__':
    main()